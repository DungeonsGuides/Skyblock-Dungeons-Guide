2 Phase Cosmetic Injection 
1. Gather data
    - and instruct the thing to replace what near what pos
2. Actually replace
   - aghhhhhh
